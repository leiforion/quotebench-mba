"""Economics layer and P&L assembly (SIM-3). Absorbs model/monte_carlo.py.

Design: operational quantities EMERGE from the discrete-event runs instead of
being assumed. Labour savings = simulated as-is engineer hours minus to-be
hours (the old harness assumed an automation rate; here the rate is an output).
The as-is economic anchor is the degraded to-be model, which reproduces the
calibrated baseline and carries defect draws.

Structure:
  lane_economics()  - price one simulation run: labour, quoted/won value,
                      discount leakage pool, quality cost (unscaled)
  build_anchors()   - DES runs per extraction variant + as-is; quality-cost
                      scale calibrated so the as-is lane reproduces BASE-31
  monte_carlo()     - 20k arithmetic draws over the anchors + financial
                      distributions; NPV/IRR/payback/P(hurdle)
  conservative_case() - 9.5 hostile case: pessimistic extraction, zero
                      elasticity, +30% build, on cost+error+discount alone
"""
from dataclasses import dataclass

import numpy as np

from .asis import TIERS
from .capability import draw_value_eur
from .tobe import ToBeModel

VARIANTS = ("pessimistic", "central", "optimistic")


@dataclass
class LaneEconomics:
    """Annualized economics of one simulated lane."""
    labour_eur: float = 0.0
    quoted_value_eur: float = 0.0
    won_value_eur: float = 0.0          # the derived revenue base (D13)
    leak_pool_eur: float = 0.0          # won discount excess over the band ref
    quality_cost_eur: float = 0.0       # unscaled defect cost
    margin_weighted_quoted: float = 0.0 # sum(quoted_t * margin_t), for uplift
    margin_weighted_won: float = 0.0    # sum(won_t * margin_t); /won = avg
                                        # realized margin (D19 gate: 24%)
    eng_hours: float = 0.0


def lane_economics(result, lane, pe, pt, seed):
    """Price one run's records. lane: 'asis' (degraded) or 'tobe'."""
    rng = np.random.default_rng(seed)
    e = LaneEconomics()
    years = result.horizon_wh / (176 * 12)
    d_lo, d_mode, d_hi = pe["discounts"]["asis_triangular"]
    band_ref = pe["discounts"]["band_reference"]
    band_top = band_ref + pe["discounts"]["band_halfwidth"]
    p_in_band = pt["routing"]["p_discount_in_band"]

    for rec in result.records:
        value = rec.value_eur if rec.value_eur > 0 else \
            draw_value_eur(rng, rec.tier, pt)
        e.labour_eur += rec.touch_eng_wh * pe["hourly_rate_eur"]
        e.eng_hours += rec.touch_eng_wh
        e.quoted_value_eur += value
        e.margin_weighted_quoted += value * pe["margin"][rec.tier]

        # win probability is expectation-weighted rather than drawn: quality
        # and leakage are rare heavy-tailed events, and Bernoulli win gates
        # add sampling noise that would swamp the small lane deltas the
        # investment case is built on. Means are unchanged.
        p_win = pe["win_rate"][rec.tier]

        # discount vs the like-for-like reference (leakage only counts on wins)
        d = rng.triangular(d_lo, d_mode, d_hi)
        if lane == "tobe":
            variant = getattr(result, "variant", "central")
            if rng.random() < p_in_band[variant]:
                d = min(d, band_top)   # banded engine caps the deep end
        e.won_value_eur += value * p_win
        e.margin_weighted_won += value * p_win * pe["margin"][rec.tier]
        e.leak_pool_eur += max(0.0, d - band_ref) * value * p_win

        # quality cost (credit notes exist only on orders)
        w = p_win if pe["error_cost_on_won_only"] else 1.0
        sf = pe["calc_site_failure"]
        for cls in rec.defects:
            if cls == "calculation":
                unit = (1 - sf["probability"]) * pe["error_unit_cost_eur"][cls] \
                    + sf["probability"] * sf["cost_eur"]
            else:
                unit = pe["error_unit_cost_eur"][cls]
            e.quality_cost_eur += w * unit

    for f in ("labour_eur", "quoted_value_eur", "won_value_eur", "leak_pool_eur",
              "quality_cost_eur", "margin_weighted_quoted", "margin_weighted_won",
              "eng_hours"):
        setattr(e, f, getattr(e, f) / years)
    return e


def build_anchors(pe, pt, pa, verbose=False):
    """Run the DES per variant and for the as-is baseline; average over seeds.
    Returns (asis: LaneEconomics, anchors: {variant: LaneEconomics}, scale)."""
    seeds = pe["monte_carlo"]["anchor_seeds"]
    years = pe["monte_carlo"]["anchor_years"]

    def avg(lanes):
        out = LaneEconomics()
        for f in vars(out):
            setattr(out, f, float(np.mean([getattr(x, f) for x in lanes])))
        return out

    asis_runs = []
    for s in seeds:
        res = ToBeModel(pt, pa, seed=s, degraded=True).run(years=years)
        asis_runs.append(lane_economics(res, "asis", pe, pt, seed=s))
    asis = avg(asis_runs)

    anchors = {}
    for v in VARIANTS:
        runs = []
        for s in seeds:
            res = ToBeModel(pt, pa, variant=v, seed=s).run(years=years)
            res.variant = v
            runs.append(lane_economics(res, "tobe", pe, pt, seed=s))
        anchors[v] = avg(runs)
        if verbose:
            print(f"  anchor {v:<12} eng hours {anchors[v].eng_hours:7.0f}  "
                  f"quality {anchors[v].quality_cost_eur:8.0f}  "
                  f"leak pool {anchors[v].leak_pool_eur:8.0f}")

    # Quality-cost scale. Pre-D19 this was calibrated so the as-is lane
    # reproduced BASE-31 (1.2% of the then-derived revenue). D19 retired that
    # target: unit costs are now value-scaled absolutes (BASE-30 x6.125), so
    # the scale is identity unless a target pct is explicitly configured.
    if "quality_cost_target_pct" in pe:
        scale = (pe["quality_cost_target_pct"] * asis.won_value_eur
                 / max(1.0, asis.quality_cost_eur))
    else:
        scale = 1.0
    return asis, anchors, scale


def interpolate(anchors, w):
    """w in [0,1]: 0 = pessimistic, 0.5 = central, 1 = optimistic."""
    lo, mid, hi = (anchors["pessimistic"], anchors["central"],
                   anchors["optimistic"])
    a, b, t = (lo, mid, w * 2) if w < 0.5 else (mid, hi, (w - 0.5) * 2)
    out = LaneEconomics()
    for f in vars(out):
        setattr(out, f, getattr(a, f) + t * (getattr(b, f) - getattr(a, f)))
    return out


def annual_benefits(asis, tobe, scale, pricing_adoption, win_uplift_pp):
    return {
        "labour_redeploy": (asis.labour_eur - tobe.labour_eur),
        "quality_savings": scale * (asis.quality_cost_eur - tobe.quality_cost_eur),
        "discount_recovery": pricing_adoption
                             * (asis.leak_pool_eur - tobe.leak_pool_eur),
        "win_uplift_margin": win_uplift_pp * tobe.margin_weighted_quoted,
    }


def npv(rate, flows):
    return float(sum(cf / (1 + rate) ** t for t, cf in enumerate(flows)))


def cashflows(benefits_total, fin, build_overrun, run_cost, change_cost):
    y0 = -(fin["build_cost_eur"] * build_overrun + change_cost)
    return [y0] + [benefits_total * ramp - run_cost
                   for ramp in fin["adoption_ramp"]]


def irr_vec(flows_matrix, lo=-0.9, hi=5.0, iters=80):
    """Vectorized bisection IRR over an (n, T) cash-flow matrix."""
    t = np.arange(flows_matrix.shape[1])

    def f(rate):
        return (flows_matrix / (1 + rate[:, None]) ** t).sum(axis=1)

    lo_v = np.full(len(flows_matrix), lo)
    hi_v = np.full(len(flows_matrix), hi)
    bad = f(lo_v) * f(hi_v) > 0        # no sign change: IRR undefined
    for _ in range(iters):
        mid = (lo_v + hi_v) / 2
        pos = f(mid) > 0
        lo_v = np.where(pos, mid, lo_v)
        hi_v = np.where(pos, hi_v, mid)
    out = (lo_v + hi_v) / 2
    out[bad] = np.nan
    return out


def payback_vec(flows_matrix):
    cum = np.cumsum(flows_matrix, axis=1)
    pb = np.full(len(flows_matrix), np.nan)
    for t in range(1, flows_matrix.shape[1]):
        newly = np.isnan(pb) & (cum[:, t] >= 0)
        frac = np.where(flows_matrix[newly, t] != 0,
                        -cum[newly, t - 1] / flows_matrix[newly, t], 0.0)
        pb[newly] = t - 1 + frac
    return pb


def monte_carlo(pe, pt, pa, seed=42, verbose=False):
    asis, anchors, scale = build_anchors(pe, pt, pa, verbose=verbose)
    out = mc_from_anchors(pe, asis, anchors, scale, seed=seed)
    out.update({"asis": asis, "anchors": anchors, "quality_scale": scale})
    return out


def mc_from_anchors(pe, asis, anchors, scale, seed=42, return_draws=False):
    """The 20k-draw financial Monte Carlo over given DES anchors. Split out so
    the SIM-5 optimizer can re-price cached runs without re-simulating."""
    fin = pe["financial"]
    mc = pe["monte_carlo"]
    n = mc["iterations"]
    rng = np.random.default_rng(seed)

    w = rng.triangular(*mc["extraction_weight_triangular"], n)
    uplift = rng.triangular(*pe["win_uplift_pp"]["triangular"], n)
    overrun = rng.triangular(*fin["build_overrun_triangular"], n)
    run_cost = rng.triangular(*fin["run_cost_yr_triangular"], n)
    change = rng.triangular(*fin["change_cost_triangular"], n)
    adoption = rng.triangular(*fin["pricing_adoption_triangular"], n)

    # vectorize the anchor interpolation per benefit component
    def anchor_vec(field):
        lo, mid, hi = (getattr(anchors[v], field) for v in VARIANTS)
        return np.where(w < 0.5, lo + w * 2 * (mid - lo),
                        mid + (w - 0.5) * 2 * (hi - mid))

    labour = asis.labour_eur - anchor_vec("labour_eur")
    quality = scale * (asis.quality_cost_eur - anchor_vec("quality_cost_eur"))
    discount = adoption * (asis.leak_pool_eur - anchor_vec("leak_pool_eur"))
    uplift_margin = uplift * anchor_vec("margin_weighted_quoted")
    benefits = labour + quality + discount + uplift_margin

    ramp = np.array(fin["adoption_ramp"])
    flows = np.empty((n, 1 + len(ramp)))
    flows[:, 0] = -(fin["build_cost_eur"] * overrun + change)
    flows[:, 1:] = benefits[:, None] * ramp[None, :] - run_cost[:, None]

    t = np.arange(flows.shape[1])
    npv12 = (flows / (1 + fin["discount_rate"]) ** t).sum(axis=1)
    npv_hurdle = (flows / (1 + fin["hurdle_rate"]) ** t).sum(axis=1)
    irrs = irr_vec(flows)
    pbs = payback_vec(flows)

    out = {
        "npv12_p10_p50_p90": [float(np.percentile(npv12, p)) for p in (10, 50, 90)],
        "npv_hurdle_p10": float(np.percentile(npv_hurdle, 10)),
        "p_clears_hurdle": float((npv_hurdle > 0).mean()),
        "irr_median": float(np.nanmedian(irrs)),
        "payback_median_years": float(np.nanmedian(pbs)),
        "benefit_medians": {
            "labour_redeploy": float(np.median(labour)),
            "quality_savings": float(np.median(quality)),
            "discount_recovery": float(np.median(discount)),
            "win_uplift_margin": float(np.median(uplift_margin)),
        },
    }
    if return_draws:
        out["npv12_draws"] = npv12
    return out


def conservative_case(pe, pt, pa, asis, anchors, scale):
    """9.5 hostile case: extraction at the pessimistic bound, elasticity zero,
    +30% build, central run/change costs. Must clear or fail the 15% hurdle on
    cost + error + discounting alone, and say which."""
    fin = pe["financial"]
    b = annual_benefits(asis, anchors["pessimistic"], scale,
                        pricing_adoption=fin["pricing_adoption_triangular"][1],
                        win_uplift_pp=0.0)
    total = sum(b.values())            # win_uplift_margin is zero by design
    flows = cashflows(total, fin, build_overrun=1.30,
                      run_cost=fin["run_cost_yr_triangular"][1],
                      change_cost=fin["change_cost_triangular"][1])
    return {
        "benefits": b,
        "npv_at_12pct": npv(fin["discount_rate"], flows),
        "npv_at_hurdle": npv(fin["hurdle_rate"], flows),
        "clears": npv(fin["hurdle_rate"], flows) > 0,
    }
